
import 'package:get/get.dart';

const title = "MapController";

class MapController extends GetxController {

}