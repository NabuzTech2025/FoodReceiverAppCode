
import 'package:get/get.dart';

const title = "WidgetController";

class WidgetController extends GetxController {

}