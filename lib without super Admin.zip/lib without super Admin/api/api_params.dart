String PARAM_STATUS_CODE = "status_code";
String PARAM_MESSAGE = "message";
String PARAM_API_KEY = "api_key";

int CODE_SUCCESS = 200;
int CODE_NO_INTERNET = 100;
int CODE_ERROR = 102;
int CODE_RESPONSE_NULL = 103;
int CODE_SERVER_ERROR = 500;
