class ParamsArgus {
  static const String APP = "app";
  static const String WIDGET = "widget";
}
